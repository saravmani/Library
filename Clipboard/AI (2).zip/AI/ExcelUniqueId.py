import openpyxl
import os
import re

excel_path = '/Users/kumar/Desktop/AI/Input.xlsx'
base, ext = os.path.splitext(excel_path)
output_indexed = f"{base}_indexed{ext}"
output_nonindexed = f"{base}_nonindexed{ext}"

def append_sequence_to_first_column(excel_path, output_path):
    wb = openpyxl.load_workbook(excel_path)
    ws = wb.active

    first_col_idx = None
    for col in ws.iter_cols():
        if any(cell.value is not None for cell in col):
            first_col_idx = col[0].column
            break

    if first_col_idx is None:
        print("No non-empty columns found.")
        return

    sequence_id = 1
    header_found = False
    for row in ws.iter_rows(min_col=first_col_idx, max_col=first_col_idx):
        cell = row[0]
        if cell.value is not None:
            if not header_found:
                header_found = True  # Skip header
            else:
                cell.value = f"{cell.value}===={sequence_id}"
                sequence_id += 1

    wb.save(output_path)
    print(f"✅ Indexed Excel file saved at {output_path}.")

def remove_sequence_from_first_column(excel_path, output_path):
    wb = openpyxl.load_workbook(excel_path)
    ws = wb.active

    first_col_idx = None
    for col in ws.iter_cols():
        if any(cell.value is not None for cell in col):
            first_col_idx = col[0].column
            break

    if first_col_idx is None:
        print("No non-empty columns found.")
        return

    header_found = False
    for row in ws.iter_rows(min_col=first_col_idx, max_col=first_col_idx):
        cell = row[0]
        if cell.value is not None:
            if not header_found:
                header_found = True  # Skip header
            else:
                # Remove the appended sequence with '====<number>'
                cell.value = re.sub(r'(====\d+)$', '', str(cell.value)).strip()

    wb.save(output_path)
    print(f"✅ Non-indexed Excel file saved at {output_path}.")

if __name__ == "__main__":
    append_sequence_to_first_column(excel_path, output_indexed)
    remove_sequence_from_first_column(output_indexed, output_nonindexed)
