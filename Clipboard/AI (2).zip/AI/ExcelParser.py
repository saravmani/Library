import openpyxl
import json
import logging
from typing import Dict

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s'
)

def load_json(json_path: str):
    try:
        with open(json_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logging.error(f"Failed to load JSON file: {e}")
        raise

def load_excel(excel_path: str):
    try:
        wb = openpyxl.load_workbook(excel_path, data_only=False)
        return wb, wb.active
    except Exception as e:
        logging.error(f"Failed to load Excel file: {e}")
        raise

def get_col_header_indices(ws) -> Dict[str, int]:
    for row in ws.iter_rows():
        if any(cell.value is not None for cell in row):
            return {str(cell.value).strip(): idx + 1 for idx, cell in enumerate(row) if cell.value is not None}
    raise ValueError("No non-empty column header row found in Excel.")

def get_row_header_indices(ws) -> Dict[str, int]:
    for col in ws.iter_cols():
        if any(cell.value is not None for cell in col):
            return {str(cell.value).strip(): idx + 1 for idx, cell in enumerate(col) if cell.value is not None}
    raise ValueError("No non-empty row header column found in Excel.")

def update_excel_from_json(json_path: str, excel_path: str):
    json_data = load_json(json_path)
    wb, ws = load_excel(excel_path)

    col_header_to_index = get_col_header_indices(ws)
    row_header_to_index = get_row_header_indices(ws)

    matched, unmatched = 0, 0

    for item in json_data:
        col_header = str(item.get("Row", "")).strip()
        row_header = str(item.get("Col", "")).strip()
        new_value = item.get("NewMark")

        row_idx = row_header_to_index.get(col_header)
        col_idx = col_header_to_index.get(row_header)

        if row_idx and col_idx:
            try:
                ws.cell(row=row_idx, column=col_idx, value=new_value)
                logging.info(f"✅ Updated: Row '{row_header}' (index {row_idx}), Col '{col_header}' (index {col_idx}) with '{new_value}'.")
                matched += 1
            except Exception as e:
                logging.error(f"❌ Failed to update cell at Row '{row_header}', Col '{col_header}': {e}")
        else:
            logging.warning(f"⚠️ Unmatched: Row '{row_header}' (found: {row_idx}), Col '{col_header}' (found: {col_idx}). Skipped.")
            unmatched += 1

    try:
        wb.save(excel_path)
        logging.info(f"✅ Excel saved successfully with {matched} updates, {unmatched} unmatched entries. Formulas preserved.")
    except Exception as e:
        logging.error(f"❌ Failed to save Excel file: {e}")
        raise

def main():
    json_path = '/Users/kumar/Desktop/AI/input.json'
    excel_path = '/Users/kumar/Desktop/AI/Input.xlsx'
    update_excel_from_json(json_path, excel_path)

if __name__ == "__main__":
    main()