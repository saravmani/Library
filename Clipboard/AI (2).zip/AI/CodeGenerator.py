import csv
import os

csv_path = '/Users/kumar/Desktop/AI/schema.csv'
output_dir = '/Users/kumar/Desktop/AI/generated_api'

type_mapping = {
    'str': 'str',
    'int': 'int',
    'float': 'float',
    'bool': 'bool',
    'datetime': 'datetime.datetime'
}

def generate_api_structure(csv_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    properties = []
    with open(csv_path, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            prop = row['PropertyName'].strip()
            typ = type_mapping.get(row['Type'].strip(), 'str')
            properties.append((prop, typ))

    # 1️⃣ models.py
    with open(os.path.join(output_dir, 'models.py'), 'w') as f:
        f.write("from pydantic import BaseModel\n")
        f.write("import datetime\n\n")
        f.write("class Item(BaseModel):\n")
        f.write("    id: int\n")
        for prop, typ in properties:
            f.write(f"    {prop}: {typ}\n")

    # 2️⃣ service.py
    with open(os.path.join(output_dir, 'service.py'), 'w') as f:
        f.write("import datetime\n\n")
        f.write("from typing import List, Optional\n")
        f.write("from models import Item\n\n")
        f.write("items_db: List[Item] = [\n")
        f.write("    Item(id=1")
        for prop, typ in properties:
            example_value = '"example"' if typ == 'str' else '1' if typ == 'int' else '1.0' if typ == 'float' else 'True' if typ == 'bool' else 'datetime.datetime.now()'
            f.write(f", {prop}={example_value}")
        f.write("),\n")
        f.write("]\n\n")
        f.write("def create_item(item: Item) -> Item:\n")
        f.write("    items_db.append(item)\n")
        f.write("    return item\n\n")
        f.write("def read_items(**filters) -> List[Item]:\n")
        f.write("    results = items_db\n")
        f.write("    for attr, value in filters.items():\n")
        f.write("        if value is not None:\n")
        f.write("            results = [item for item in results if getattr(item, attr) == value]\n")
        f.write("    return results\n\n")
        f.write("def read_item_by_id(item_id: int) -> Optional[Item]:\n")
        f.write("    for item in items_db:\n")
        f.write("        if item.id == item_id:\n")
        f.write("            return item\n")
        f.write("    return None\n\n")
        f.write("def delete_item(item_id: int) -> bool:\n")
        f.write("    for idx, item in enumerate(items_db):\n")
        f.write("        if item.id == item_id:\n")
        f.write("            del items_db[idx]\n")
        f.write("            return True\n")
        f.write("    return False\n")

    # 3️⃣ controllers.py
    with open(os.path.join(output_dir, 'controllers.py'), 'w') as f:
        f.write("from fastapi import APIRouter, HTTPException\n")
        f.write("from typing import List, Optional\n")
        f.write("from models import Item\n")
        f.write("import service\n")
        f.write("import datetime\n\n")
        f.write("router = APIRouter()\n\n")
        # POST
        f.write("@router.post('/items', response_model=Item)\n")
        f.write("def create(item: Item):\n")
        f.write("    return service.create_item(item)\n\n")
        # GET all with filters
        filter_params = ", ".join([f"{prop}: Optional[{typ}] = None" for prop, typ in properties])
        f.write(f"@router.get('/items', response_model=List[Item])\n")
        f.write(f"def read_all({filter_params}):\n")
        f.write("    filters = {")
        f.write(", ".join([f"'{prop}': {prop}" for prop, _ in properties]))
        f.write("}\n")
        f.write("    return service.read_items(**filters)\n\n")
        # GET by ID
        f.write("@router.get('/items/{item_id}', response_model=Item)\n")
        f.write("def read_by_id(item_id: int):\n")
        f.write("    item = service.read_item_by_id(item_id)\n")
        f.write("    if item:\n")
        f.write("        return item\n")
        f.write("    raise HTTPException(status_code=404, detail='Item not found')\n\n")
        # DELETE
        f.write("@router.delete('/items/{item_id}')\n")
        f.write("def delete(item_id: int):\n")
        f.write("    if service.delete_item(item_id):\n")
        f.write("        return {'detail': 'Item deleted'}\n")
        f.write("    raise HTTPException(status_code=404, detail='Item not found')\n")

    # 4️⃣ main.py
    with open(os.path.join(output_dir, 'main.py'), 'w') as f:
        f.write("from fastapi import FastAPI\n")
        f.write("from controllers import router\n\n")
        f.write("app = FastAPI()\n")
        f.write("app.include_router(router)\n\n")
        f.write("if __name__ == '__main__':\n")
        f.write("    import uvicorn\n")
        f.write("    uvicorn.run('main:app', host='127.0.0.1', port=8000, reload=True)\n")

    print(f"✅ API generated in {output_dir}.")
    print(f"Run using: uvicorn main:app --reload (inside {output_dir})")

if __name__ == '__main__':
    generate_api_structure(csv_path, output_dir)
