import csv
import os

csv_path = '/Users/kumar/Desktop/AI/schema.csv'
output_dir = '/Users/kumar/Desktop/AI/generated_api'

type_mapping = {
    'str': 'str',
    'int': 'int',
    'float': 'float',
    'bool': 'bool',
    'datetime': 'datetime.datetime'
}

def generate_api_structure(csv_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    properties = []
    with open(csv_path, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            prop = row['PropertyName'].strip()
            typ = type_mapping.get(row['Type'].strip(), 'str')
            properties.append((prop, typ))

    # 1️⃣ models.py
    with open(os.path.join(output_dir, 'models.py'), 'w') as f:
        f.write("import datetime\n\n")
        f.write("from pydantic import BaseModel\n")
        f.write("import datetime\n\n")
        f.write("class Item(BaseModel):\n")
        f.write("    id: int\n")
        for prop, typ in properties:
            f.write(f"    {prop}: {typ}\n")

    # 2️⃣ service.py with SQLite and 50 mocked objects
    with open(os.path.join(output_dir, 'service.py'), 'w') as f:
        f.write("from typing import List, Optional\n")
        f.write("from models import Item\n")
        f.write("import sqlite3\n")
        f.write("import datetime\n\n")

        f.write("conn = sqlite3.connect('items.db', check_same_thread=False)\n")
        f.write("cursor = conn.cursor()\n")

        columns = ', '.join([f"{prop} TEXT" for prop, _ in properties])
        f.write(f"cursor.execute(\"CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, {columns})\")\n")
        f.write("conn.commit()\n\n")

        # Insert 50 mocked objects if table is empty
        f.write("cursor.execute('SELECT COUNT(*) FROM items')\n")
        f.write("count = cursor.fetchone()[0]\n")
        f.write("if count == 0:\n")
        f.write("    for i in range(1, 51):\n")
        col_names = ', '.join([prop for prop, _ in properties])
        placeholders = ', '.join(['?' for _ in properties])
        example_values = []
        for prop, typ in properties:
            if typ == 'str':
                example_values.append(f"f'Mock{{i}}_{prop}'")
            elif typ == 'int':
                example_values.append('str(i)')
            elif typ == 'float':
                example_values.append('str(float(i) + 0.5)')
            elif typ == 'bool':
                example_values.append('str(i % 2 == 0)')
            else:  # datetime
                example_values.append('datetime.datetime.now().isoformat()')
        values_code = ', '.join(example_values)
        f.write(f"        cursor.execute(\"INSERT INTO items (id, {col_names}) VALUES (?, {placeholders})\", ([i] + [{values_code}]))\n")
        f.write("    conn.commit()\n\n")

        f.write("def create_item(item: Item) -> Item:\n")
        f.write(f"    cursor.execute(\"INSERT INTO items (id, {col_names}) VALUES (?, {placeholders})\", ([item.id] + [getattr(item, prop) for prop, _ in {properties}]))\n")
        f.write("    conn.commit()\n")
        f.write("    return item\n\n")

        f.write("def read_items(**filters) -> List[Item]:\n")
        f.write("    query = 'SELECT * FROM items'\n")
        f.write("    conditions = []\n")
        f.write("    values = []\n")
        f.write("    for attr, value in filters.items():\n")
        f.write("        if value is not None:\n")
        f.write("            conditions.append(f'{attr} = ?')\n")
        f.write("            values.append(value)\n")
        f.write("    if conditions:\n")
        f.write("        query += ' WHERE ' + ' AND '.join(conditions)\n")
        f.write("    cursor.execute(query, values)\n")
        f.write("    rows = cursor.fetchall()\n")
        f.write("    items = []\n")
        f.write("    for row in rows:\n")
        f.write("        item_dict = {'id': row[0]}\n")
        for idx, (prop, typ) in enumerate(properties, start=1):
            f.write(f"        item_dict['{prop}'] = row[{idx}]\n")
        f.write("        items.append(Item(**item_dict))\n")
        f.write("    return items\n\n")

        f.write("def read_item_by_id(item_id: int) -> Optional[Item]:\n")
        f.write("    cursor.execute('SELECT * FROM items WHERE id = ?', (item_id,))\n")
        f.write("    row = cursor.fetchone()\n")
        f.write("    if row:\n")
        f.write("        item_dict = {'id': row[0]}\n")
        for idx, (prop, typ) in enumerate(properties, start=1):
            f.write(f"        item_dict['{prop}'] = row[{idx}]\n")
        f.write("        return Item(**item_dict)\n")
        f.write("    return None\n\n")

        f.write("def delete_item(item_id: int) -> bool:\n")
        f.write("    cursor.execute('DELETE FROM items WHERE id = ?', (item_id,))\n")
        f.write("    conn.commit()\n")
        f.write("    return cursor.rowcount > 0\n")

    # 3️⃣ controllers.py
    with open(os.path.join(output_dir, 'controllers.py'), 'w') as f:
        f.write("import datetime\n\n")
        f.write("from fastapi import APIRouter, HTTPException\n")
        f.write("from typing import List, Optional\n")
        f.write("from models import Item\n")
        f.write("import service\n")
        f.write("import datetime\n\n")
        f.write("router = APIRouter()\n\n")
        # POST
        f.write("@router.post('/items', response_model=Item)\n")
        f.write("def create(item: Item):\n")
        f.write("    return service.create_item(item)\n\n")
        # GET all with filters
        filter_params = ", ".join([f"{prop}: Optional[str] = None" for prop, _ in properties])
        f.write(f"@router.get('/items', response_model=List[Item])\n")
        f.write(f"def read_all({filter_params}):\n")
        f.write("    filters = {")
        f.write(", ".join([f"'{prop}': {prop}" for prop, _ in properties]))
        f.write("}\n")
        f.write("    return service.read_items(**filters)\n\n")
        # GET by ID
        f.write("@router.get('/items/{item_id}', response_model=Item)\n")
        f.write("def read_by_id(item_id: int):\n")
        f.write("    item = service.read_item_by_id(item_id)\n")
        f.write("    if item:\n")
        f.write("        return item\n")
        f.write("    raise HTTPException(status_code=404, detail='Item not found')\n\n")
        # DELETE
        f.write("@router.delete('/items/{item_id}')\n")
        f.write("def delete(item_id: int):\n")
        f.write("    if service.delete_item(item_id):\n")
        f.write("        return {'detail': 'Item deleted'}\n")
        f.write("    raise HTTPException(status_code=404, detail='Item not found')\n")

    # 4️⃣ main.py
    with open(os.path.join(output_dir, 'main.py'), 'w') as f:
        f.write("from fastapi import FastAPI\n")
        f.write("from controllers import router\n\n")
        f.write("app = FastAPI()\n")
        f.write("app.include_router(router)\n\n")
        f.write("if __name__ == '__main__':\n")
        f.write("    import uvicorn\n")
        f.write("    uvicorn.run('main:app', host='127.0.0.1', port=8000, reload=True)\n")

    print(f"✅ API with SQLite persistence and 50 mock objects generated in {output_dir}.")
    print(f"Run using: uvicorn main:app --reload (inside {output_dir})")

if __name__ == '__main__':
    generate_api_structure(csv_path, output_dir)